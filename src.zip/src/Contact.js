import React from 'react';
import './App.css';

function Contact() {
  return (
    <div className="contact-container">
      <h2 className="text-4xl font-bold text-red-800 mb-8">Reach out to us</h2>

      {/* Contact Form */}
      <div className="contact-form">
        <div className="contact-form-grid">
          <input type="text" placeholder="Name" className="contact-input" />
          <input type="text" placeholder="Phone" className="contact-input" />
          <input type="email" placeholder="E-mail" className="contact-input" />
          <input type="text" placeholder="What are you interested in ?" className="contact-input" />
        </div>
        <button className="contact-button">Get in Touch ➝</button>
      </div>

      {/* Campus Section */}
      <div className="section">
        <div className="flex-1">
          <h3 className="text-xl font-bold text-red-800 mb-2">Campus</h3>
          <p>Vignana Jyothi Nagar, Pragathi Nagar,<br />
            Nizampet (S.O), Hyderabad,<br />
            Telangana, India - 500 090</p>
          <p className="mt-3">📞 91-040-23042758 /59/60</p>
          <p>📠 91-040-23042761</p>
          <p>✉️ postbox@vnrvjiet.ac.in</p>
        </div>
        <iframe
          className="map"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3806.6235321129496!2d78.3912461750496!3d17.42930268349478!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb91aaae26419d%3A0x32f0c18210c86e7e!2sVallurupalli%20Nageswara%20Rao%20Vignana%20Jyothi%20Institute%20of%20Engineering%20and%20Technology!5e0!3m2!1sen!2sin!4v1620911717779!5m2!1sen!2sin"
          allowFullScreen=""
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </div>

      {/* Head Office Section */}
      <div className="section">
        <div className="flex-1">
          <h3 className="text-xl font-bold text-red-800 mb-2">Head Office</h3>
          <p>Vignana Jyothi<br />
            H.No. 7-1-4, Begumpet<br />
            Hyderabad - 500 016</p>
          <p className="mt-3">📞 040-23731555</p>
        </div>
        <iframe
          className="map"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3806.327661765465!2d78.4541103750499!3d17.44569578348464!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb90e658ba2e0b%3A0x2e30a70b7ff4d3a6!2sVignana%20Jyothi!5e0!3m2!1sen!2sin!4v1620911871551!5m2!1sen!2sin"
          allowFullScreen=""
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </div>
    </div>
  );
}

export default Contact;
