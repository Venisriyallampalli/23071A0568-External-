import React from 'react';
import './App.css';
function About() {
  return (
    <div className="px-6 py-10 max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold text-red-800 mb-4">Welcome to VNRVJIET</h2>
      <p className="mb-4">
        The Philosophy of Vignana Jyothi unravels education as a process of “Presencing” that provides, both individually and collectively,
        to one’s deepest capacity to sense and experience the knowledge and activities to shape the future. Based on a synthesis of direct experience,
        leading edge thinking and ancient wisdom, it taps into ‘deeper levels of LEARNING for discovering new possibilities’.
      </p>
      <p className="mb-4">
        Today, with this philosophy, Vignana Jyothi has created an edifice that is strong in its foundations, which can only rise higher and higher.
        Quality and integrity is the essence for achieving excellence at Vignana Jyothi institutions. This and quest for excellence reflects in the
        vision and mission. Their passion reflects in the enterprise of education.
      </p>
      <div className="grid md:grid-cols-3 gap-8 mt-10">
        <div>
          <h3 className="text-xl font-semibold text-red-700">Vision</h3>
          <p>
            To be a World Class University providing value-based education, conducting interdisciplinary research in cutting edge technologies leading to sustainable socio-economic development of the nation.
          </p>
        </div>
        <div>
          <h3 className="text-xl font-semibold text-red-700">Mission</h3>
          <ul className="list-disc list-inside">
            <li>To produce technically competent and socially responsible engineers, managers and entrepreneurs, who will be future ready.</li>
            <li>To involve students and faculty in innovative research projects linked with industry, academic and research institutions in India and abroad.</li>
            <li>To use modern pedagogy for improving the teaching-learning process.</li>
          </ul>
        </div>
        <div>
          <h3 className="text-xl font-semibold text-red-700">Quality Policy</h3>
          <ul className="list-disc list-inside">
            <li>Impart up-to-date knowledge in the students’ chosen fields to make them quality engineers</li>
            <li>Make the students experience the applications on quality equipment and tools</li>
            <li>Provide quality environment and services to all stakeholders</li>
            <li>Provide systems, resources and opportunities for continuous improvement</li>
            <li>Maintain global standards in education, training and services</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default About;
